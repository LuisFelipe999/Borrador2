package com.example.demo.services;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.models.Login;
import com.example.demo.models.Usuario;
import com.example.demo.repository.RegistroRepository;
import com.example.demo.repository.UsuarioRepository;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



@Service
public class UsuarioService implements RegistroRepository {

	@Autowired
	private UsuarioRepository userRepository;
	@Override
	@Transactional
	public Usuario newReg(Usuario theNewCustomerEntity) {
		return userRepository.save(theNewCustomerEntity);
	}
	@Override
	@Transactional
	public Optional<Usuario> findById(Integer Id) {
		return userRepository.findById(Id);
	}
	
	@Transactional
	public Usuario ingreso(Login login) {
		Optional<Usuario> userOptional = userRepository.findByEmail(login.getEmailId());
		if (userOptional.isEmpty()) {
			throw new RuntimeException("User does not exist");
		}
		Usuario user = userOptional.get();
		if (!login.getPassword().equals(user.getPassword())) {
			throw new RuntimeException("Incorrect Password");
		}
		return user;
	}

	@Override
	public Usuario logIn(com.example.demo.models.Login login) {
		// TODO Auto-generated method stub
		return null;
	}

}
