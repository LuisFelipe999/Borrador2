package com.example.demo.controllers;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.models.Login;
import com.example.demo.models.Usuario;
import com.example.demo.repository.RegistroRepository;


@CrossOrigin (origins="http://localhost:4200")
@RestController
@RequestMapping("/api")
public class UsuarioController {
	@Autowired
	private RegistroRepository regForm;

	@PostMapping("/newuser")
	public Usuario userRest(@RequestBody Usuario theNewCustomerEntity) {
		theNewCustomerEntity = regForm.newReg(theNewCustomerEntity);
		return theNewCustomerEntity;
	}

	@GetMapping("/newuser/{Id}")
	public Optional<Usuario> getUser(@PathVariable Integer Id) throws Exception {
		Optional<Usuario> thCustomerEntity = regForm.findById(Id);
		if (thCustomerEntity == null) {
			throw new Exception("Customer id not found - " + Id);
		}

		return thCustomerEntity;
	}

	@PostMapping("/login")
	public Usuario login(@Valid @RequestBody Login login) throws Exception {
		Usuario theCustomerEntity = regForm.logIn(login);
		return theCustomerEntity;
	}

}
