package com.example.demo.repository;

import java.util.Optional;

import com.example.demo.models.Login;
import com.example.demo.models.Usuario;



public interface RegistroRepository {
public Usuario newReg(Usuario theNewCustomerEntity);
	
	public Optional<Usuario> findById(Integer id);
	
	public Usuario logIn(Login login);
}
